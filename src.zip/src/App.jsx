import { useState, useEffect } from "react";
import {
  LayoutDashboard,
  ClipboardList,
  Store,
  Users,
  ShieldCheck,
  Send,
  UserSquare2,
} from "lucide-react";
import { Sidebar } from "./components/Sidebar";
import { Topbar } from "./components/Topbar";
import { LoadingScreen, ErrorScreen } from "./components/LoadingScreen";
import { LoginPage } from "./pages/LoginPage";
import { DashboardPage } from "./pages/DashboardPage";
import { CampaignsPage } from "./pages/CampaignsPage";
import { ProducersPage } from "./pages/ProducersPage";
import { AdminPage } from "./pages/AdminPage";
import { VendorDashboardPage } from "./pages/VendorDashboardPage";
import { VendorProductsPage } from "./pages/VendorProductsPage";
import { VendorProfilePage } from "./pages/VendorProfilePage";
import { VendorsPage } from "./pages/VendorsPage";
import { ProducerPortalPage } from "./pages/ProducerPortalPage";
import { useCampaigns } from "./hooks/useCampaigns";
import { useVendorProducts } from "./hooks/useVendorProducts";
import { useAuth } from "./hooks/useAuth";
import { ROLES } from "./constants/roles";
import styles from "./App.module.css";

const isPortalRoute = () =>
  window.location.pathname === "/portalforms" ||
  window.location.hash === "#/portalforms";

function defaultPageForRole(role) {
  if (role === ROLES.VENDOR) return "vendor-dashboard";
  if (role === ROLES.ADMIN) return "admin";
  return "dashboard";
}

const ALLOWED = {
  [ROLES.GESTOR]: ["dashboard", "campaigns", "producers", "vendors"],
  [ROLES.VENDOR]: ["vendor-dashboard", "vendor-profile"],
  [ROLES.ADMIN]: ["dashboard", "campaigns", "producers", "admin", "vendors"],
};

const PAGE_TITLES = {
  dashboard: "Dashboard",
  campaigns: "Cotações",
  producers: "Compradores",
  vendors: "Fornecedores",
  admin: "Monitoramento Financeiro",
  financial: "Financeiro",
  "vendor-dashboard": "Propostas",
  "vendor-profile": "Meu Perfil",
};

// ── Bottom Navigation (mobile only) ───────────────────────────────────────
function BottomNav({ page, setPage, role, blocked }) {
  const items =
    role === ROLES.VENDOR
      ? [
          { id: "vendor-dashboard", label: "Propostas", Icon: Send },
          { id: "vendor-profile", label: "Perfil", Icon: UserSquare2 },
        ]
      : role === ROLES.ADMIN
        ? [
            { id: "dashboard", label: "Início", Icon: LayoutDashboard },
            { id: "campaigns", label: "Cotações", Icon: ClipboardList },
            { id: "vendors", label: "Fornecedores", Icon: Store },
            { id: "producers", label: "Compradores", Icon: Users },
            { id: "admin", label: "Admin", Icon: ShieldCheck },
          ]
        : [
            { id: "dashboard", label: "Início", Icon: LayoutDashboard },
            { id: "campaigns", label: "Cotações", Icon: ClipboardList },
            { id: "vendors", label: "Fornecedores", Icon: Store },
            { id: "producers", label: "Compradores", Icon: Users },
          ];

  return (
    <nav className="bottomNav">
      {items.map(({ id, label, Icon }) => {
        const isLocked = blocked && id !== "dashboard";
        return (
          <button
            key={id}
            className={`bottomNavItem ${page === id ? "active" : ""}`}
            onClick={() => !isLocked && setPage(id)}
            disabled={isLocked}
          >
            <Icon size={20} />
            {label}
          </button>
        );
      })}
    </nav>
  );
}

export default function App() {
  const [isPortal, setIsPortal] = useState(isPortalRoute);
  const {
    user,
    loading: authLoading,
    error: authError,
    signIn,
    signUp,
    signOut,
  } = useAuth();
  const [page, setPage] = useState(() => defaultPageForRole(user?.role));

  // ── Estado global de campanhas / vendors
  const {
    campaigns,
    vendors,
    loading,
    error,
    reload,
    addCampaign,
    addOrder,
    removeOrder,
    saveFinancials,
    closeCampaign,
    finishCampaign,
    reopenCampaign,
    publishToVendors,
    deleteCampaign,
    addPendingOrder,
    approvePending,
    rejectPending,
    addLot,
    removeLot,
    addVendor,
    removeVendor,
    reloadCampaign,
    ownVendor,
  } = useCampaigns(user);

  // ── Estado global de produtos do fornecedor (só ativo para vendors)
  // For vendor role: use ownVendor (their own record fetched directly)
  // For gestor/admin: find in vendors array
  const vendor =
    user?.role === ROLES.VENDOR
      ? (ownVendor ?? null)
      : (vendors?.find((v) => v.user_id === user?.id) ?? null);
  const vendorId = vendor?.id ?? null;
  const {
    products,
    loading: productsLoading,
    saveProduct,
    removeProduct,
    addPromo,
    removePromo,
  } = useVendorProducts(user?.role === ROLES.VENDOR ? vendorId : null);

  // ── Estado global de gestors (só ativo para vendors)
  // ── Vendor profile: atualiza vendor local no array sem reload
  const handleVendorUpdate = (updated) => {
    // vendors vem do useCampaigns; atualizamos o estado de campaigns indiretamente
    // como vendors é array simples, fazemos reload leve só de vendors
    reload();
  };

  // listeners de rota
  useEffect(() => {
    const check = () => setIsPortal(isPortalRoute());
    window.addEventListener("hashchange", check);
    window.addEventListener("popstate", check);
    return () => {
      window.removeEventListener("hashchange", check);
      window.removeEventListener("popstate", check);
    };
  }, []);

  useEffect(() => {
    const open = isPortal || !user;
    document.body.style.overflow = open ? "auto" : "";
    document.body.style.height = open ? "auto" : "";
  }, [isPortal, user]);

  useEffect(() => {
    if (user) {
      // Novo usuário logado: navega para a página padrão do seu papel
      setPage(defaultPageForRole(user.role));
    } else {
      // Usuário deslogado: garante que a página volta ao estado neutro
      setPage("dashboard");
    }
  }, [user?.id]); // ← depende do ID, não só do role — detecta troca de conta

  const navigate = (target) => {
    if (user?.blocked && target !== "dashboard") return;
    const allowed =
      ALLOWED[user?.role ?? ROLES.GESTOR] ?? ALLOWED[ROLES.GESTOR];
    if (allowed.includes(target)) setPage(target);
  };

  if (isPortal) return <ProducerPortalPage onSubmit={addPendingOrder} />;
  if (!user)
    return (
      <LoginPage
        onLogin={signIn}
        onRegister={signUp}
        loading={authLoading}
        error={authError}
      />
    );

  const role = user.role ?? ROLES.GESTOR;

  const campaignActions = {
    addCampaign,
    addOrder,
    removeOrder,
    saveFinancials,
    closeCampaign,
    finishCampaign,
    reopenCampaign,
    publishToVendors,
    deleteCampaign,
    approvePending,
    rejectPending,
    addLot,
    removeLot,
    addVendor,
    removeVendor,
    reload,
    reloadCampaign,
  };

  const renderPage = () => {
    if (loading) return <LoadingScreen message="Carregando…" />;
    if (error) return <ErrorScreen message={error} onRetry={reload} />;

    const allowed = ALLOWED[role] ?? ALLOWED[ROLES.GESTOR];
    const safePage = allowed.includes(page) ? page : defaultPageForRole(role);

    switch (safePage) {
      case "dashboard":
        return (
          <DashboardPage campaigns={campaigns} setPage={navigate} user={user} />
        );

      case "campaigns":
        return (
          <CampaignsPage
            campaigns={campaigns}
            vendors={vendors}
            actions={campaignActions}
            user={user}
            setPage={navigate}
          />
        );

      case "producers":
        return <ProducersPage campaigns={campaigns} user={user} />;

      case "vendors":
        return (
          <VendorsPage
            vendors={vendors}
            campaigns={campaigns}
            actions={campaignActions}
            user={user}
          />
        );

      case "admin":
        return (
          <AdminPage
            campaigns={campaigns}
            actions={campaignActions}
            reload={reload}
          />
        );

      case "vendor-dashboard":
        return (
          <VendorDashboardPage
            campaigns={campaigns}
            vendors={vendors}
            vendor={vendor}
            user={user}
          />
        );

      case "vendor-products":
        return (
          <VendorProductsPage
            user={user}
            vendor={vendor}
            products={products}
            loading={productsLoading}
            onSave={saveProduct}
            onDelete={removeProduct}
            onAddPromo={addPromo}
            onDeletePromo={removePromo}
          />
        );

      case "vendor-profile":
        return (
          <VendorProfilePage
            user={user}
            vendor={vendor}
            onSaved={handleVendorUpdate}
          />
        );

      default:
        return (
          <DashboardPage campaigns={campaigns} setPage={navigate} user={user} />
        );
    }
  };

  return (
    <div className={styles.app}>
      <Sidebar
        page={page}
        setPage={navigate}
        open={false}
        onClose={() => {}}
        user={user}
        blocked={user?.blocked}
      />
      <SidebarMobile page={page} setPage={navigate} user={user} />
      <div className={`${styles.main} mainWithBottomNav`}>
        <Topbar
          title={PAGE_TITLES[page] ?? ""}
          onMenuClick={() => document.dispatchEvent(new Event("open-sidebar"))}
          onPortalClick={() => window.open("/portalforms", "_blank")}
          user={user}
          onLogout={() => signOut()}
          onProfile={() => navigate("vendor-profile")}
        />
        <div className={styles.content}>{renderPage()}</div>
      </div>
      <BottomNav
        page={page}
        setPage={navigate}
        role={user?.role ?? ROLES.GESTOR}
        blocked={user?.blocked}
      />
    </div>
  );
}

function SidebarMobile({ page, setPage, user }) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const h = () => setOpen(true);
    document.addEventListener("open-sidebar", h);
    return () => document.removeEventListener("open-sidebar", h);
  }, []);
  return (
    <Sidebar
      page={page}
      setPage={setPage}
      open={open}
      onClose={() => setOpen(false)}
      user={user}
      blocked={user?.blocked}
    />
  );
}
